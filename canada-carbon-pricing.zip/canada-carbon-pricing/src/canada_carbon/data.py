"""Canada carbon pricing data - federal and provincial systems."""

# Federal carbon price trajectory ($/tonne CO2)
FEDERAL_CARBON_PRICE = {
    2023: 65, 2024: 80, 2025: 95, 2026: 110, 2027: 125,
    2028: 140, 2029: 155, 2030: 170, 2035: 170, 2040: 170,
}

# Provincial systems
PROVINCIAL_SYSTEMS = {
    "alberta": {
        "name": "TIER (Technology Innovation & Emissions Reduction)",
        "type": "output_based",
        "price_follows_federal": True,
        "benchmark_stringency": 0.90,  # 90% of sector benchmark
        "sectors": ["oil_sands", "refineries", "chemicals", "power"],
    },
    "british_columbia": {
        "name": "BC Carbon Tax",
        "type": "carbon_tax",
        "price": {2023: 65, 2024: 80, 2025: 95, 2030: 170},
        "covers_all_fuels": True,
    },
    "saskatchewan": {
        "name": "OBPS (Output-Based Performance Standards)",
        "type": "output_based",
        "price_follows_federal": True,
        "benchmark_stringency": 0.86,
    },
    "ontario": {
        "name": "EPS (Emissions Performance Standards)",
        "type": "output_based",
        "price_follows_federal": True,
        "benchmark_stringency": 0.90,
    },
    "quebec": {
        "name": "Cap-and-Trade (WCI)",
        "type": "cap_and_trade",
        "price": {2023: 47, 2024: 55, 2025: 65, 2030: 100},  # Linked to California
        "linked_to": "California",
    },
}

# Oil sands emission intensities (kg CO2/bbl)
OIL_SANDS_INTENSITY = {
    "sagd": {"average": 70, "best": 50, "worst": 100},
    "css": {"average": 80, "best": 60, "worst": 110},
    "mining": {"average": 45, "best": 35, "worst": 65},
    "upgrader": {"average": 55, "best": 40, "worst": 75},
}

# TIER benchmarks (tCO2/unit production)
TIER_BENCHMARKS = {
    "oil_sands_sagd": 0.37,  # tCO2/bbl
    "oil_sands_mining": 0.28,
    "conventional_oil": 0.12,
    "refining": 0.022,  # tCO2/bbl throughput
    "natural_gas_processing": 0.0008,  # tCO2/m3
    "power_generation": 0.37,  # tCO2/MWh
}

# Canadian refineries
CANADA_REFINERIES = {
    "irving_saint_john": {"province": "new_brunswick", "capacity_bpd": 320000},
    "suncor_montreal": {"province": "quebec", "capacity_bpd": 137000},
    "valero_levis": {"province": "quebec", "capacity_bpd": 265000},
    "imperial_sarnia": {"province": "ontario", "capacity_bpd": 121000},
    "suncor_sarnia": {"province": "ontario", "capacity_bpd": 85000},
    "imperial_strathcona": {"province": "alberta", "capacity_bpd": 191000},
    "suncor_edmonton": {"province": "alberta", "capacity_bpd": 146000},
    "parkland_burnaby": {"province": "british_columbia", "capacity_bpd": 55000},
}

def get_federal_price(year: int) -> float:
    years = sorted(FEDERAL_CARBON_PRICE.keys())
    if year <= years[0]: return FEDERAL_CARBON_PRICE[years[0]]
    if year >= years[-1]: return FEDERAL_CARBON_PRICE[years[-1]]
    for i in range(len(years)-1):
        if years[i] <= year <= years[i+1]:
            p1, p2 = FEDERAL_CARBON_PRICE[years[i]], FEDERAL_CARBON_PRICE[years[i+1]]
            return p1 + (p2-p1)*(year-years[i])/(years[i+1]-years[i])
    return FEDERAL_CARBON_PRICE[years[-1]]
