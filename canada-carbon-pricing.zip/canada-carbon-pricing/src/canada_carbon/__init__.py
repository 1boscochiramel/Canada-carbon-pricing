"""Canada Carbon Pricing Calculator."""
__version__ = "1.0.0"
__author__ = "Bosco Chiramel"
from .calculator import CanadaCarbonCalculator, CarbonCostResult, calculate_carbon_cost, quick_cost
from .data import FEDERAL_CARBON_PRICE, PROVINCIAL_SYSTEMS, OIL_SANDS_INTENSITY, TIER_BENCHMARKS, CANADA_REFINERIES
__all__ = ["CanadaCarbonCalculator", "CarbonCostResult", "calculate_carbon_cost", "quick_cost",
           "FEDERAL_CARBON_PRICE", "PROVINCIAL_SYSTEMS", "OIL_SANDS_INTENSITY", "TIER_BENCHMARKS"]
