"""Canada Carbon Pricing Calculator - Federal, Provincial, TIER systems."""
from dataclasses import dataclass
from typing import Dict, List, Optional
from .data import (FEDERAL_CARBON_PRICE, PROVINCIAL_SYSTEMS, OIL_SANDS_INTENSITY,
                   TIER_BENCHMARKS, CANADA_REFINERIES, get_federal_price)

@dataclass
class CarbonCostResult:
    annual_cost_cad: float  # CAD/year
    cost_per_bbl: float  # CAD/bbl
    emissions_mtpa: float
    carbon_price: float
    province: str
    year: int
    system_type: str
    
    def summary(self) -> str:
        return f"""
{'='*50}
CANADA CARBON COST - {self.province.upper()} ({self.year})
{'='*50}
Annual Cost:     ${self.annual_cost_cad/1e6:.1f}M CAD
Cost per Barrel: ${self.cost_per_bbl:.2f} CAD/bbl
{'='*50}
Emissions:       {self.emissions_mtpa:.2f} Mt CO2/year
Carbon Price:    ${self.carbon_price:.0f}/tonne
System:          {self.system_type}
{'='*50}
"""

class CanadaCarbonCalculator:
    """Calculator for Canadian carbon pricing costs."""
    
    def calculate_oil_sands(
        self,
        production_bpd: int = 100000,
        extraction_type: str = "sagd",  # sagd, css, mining
        intensity: Optional[float] = None,  # kg CO2/bbl, or use default
        year: int = 2026,
        tier_benchmark: Optional[float] = None,
    ) -> CarbonCostResult:
        # Get intensity
        if intensity is None:
            intensity = OIL_SANDS_INTENSITY[extraction_type]["average"]
        
        # Annual emissions
        annual_bbl = production_bpd * 365 * 0.90  # 90% utilization
        emissions_tonnes = annual_bbl * intensity / 1000  # kg to tonnes
        
        # TIER: Pay only for emissions above benchmark
        benchmark = tier_benchmark or TIER_BENCHMARKS.get(f"oil_sands_{extraction_type}", 0.37)
        benchmark_emissions = annual_bbl * benchmark
        # Pay on portion above benchmark (assume 80% get free allocation)
        excess_emissions = emissions_tonnes * 0.20  # Simplified: pay on ~20% above benchmark
        
        # Carbon price
        price = get_federal_price(year)
        annual_cost = excess_emissions * price
        cost_per_bbl = annual_cost / annual_bbl
        
        return CarbonCostResult(
            annual_cost_cad=annual_cost,
            cost_per_bbl=cost_per_bbl,
            emissions_mtpa=emissions_tonnes / 1e6,
            carbon_price=price,
            province="alberta",
            year=year,
            system_type="TIER (Output-Based)",
        )
    
    def calculate_refinery(
        self,
        refinery: str = "imperial_strathcona",
        year: int = 2026,
        intensity_kg_per_bbl: float = 35,
    ) -> CarbonCostResult:
        ref = CANADA_REFINERIES[refinery]
        province = ref["province"]
        capacity = ref["capacity_bpd"]
        
        annual_bbl = capacity * 365 * 0.90
        emissions_tonnes = annual_bbl * intensity_kg_per_bbl / 1000
        
        # Check if OBPS/TIER or direct carbon tax
        prov_sys = PROVINCIAL_SYSTEMS.get(province, {})
        price = get_federal_price(year)
        
        if prov_sys.get("type") == "output_based":
            benchmark = TIER_BENCHMARKS.get("refining", 0.022)
            benchmark_emissions = annual_bbl * benchmark
            excess = max(0, emissions_tonnes - benchmark_emissions)
            annual_cost = excess * price
            system = prov_sys.get("name", "OBPS")
        elif prov_sys.get("type") == "cap_and_trade":
            # Quebec - different price
            price = prov_sys["price"].get(year, 65)
            annual_cost = emissions_tonnes * price * 0.85  # Free allocation ~15%
            system = "Cap-and-Trade (WCI)"
        else:
            annual_cost = emissions_tonnes * price
            system = "Federal Carbon Tax"
        
        return CarbonCostResult(
            annual_cost_cad=annual_cost,
            cost_per_bbl=annual_cost / annual_bbl,
            emissions_mtpa=emissions_tonnes / 1e6,
            carbon_price=price,
            province=province,
            year=year,
            system_type=system,
        )
    
    def compare_provinces(self, year: int = 2026) -> Dict[str, float]:
        return {p: get_federal_price(year) if s.get("price_follows_federal", True) 
                else s.get("price", {}).get(year, 65) 
                for p, s in PROVINCIAL_SYSTEMS.items()}
    
    def price_trajectory(self, years: List[int] = None) -> List[dict]:
        if years is None:
            years = list(range(2024, 2035))
        return [{"year": y, "federal_price": get_federal_price(y)} for y in years]
    
    def compare_refineries(self, year: int = 2026) -> Dict[str, CarbonCostResult]:
        return {r: self.calculate_refinery(r, year) for r in CANADA_REFINERIES}

def calculate_carbon_cost(production_bpd: int = 100000, **kwargs) -> CarbonCostResult:
    return CanadaCarbonCalculator().calculate_oil_sands(production_bpd=production_bpd, **kwargs)

def quick_cost(year: int = 2026) -> float:
    """Return federal carbon price for year."""
    return get_federal_price(year)
