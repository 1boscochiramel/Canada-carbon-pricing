import pytest, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
from canada_carbon import calculate_carbon_cost, quick_cost, CanadaCarbonCalculator

def test_quick_cost():
    assert quick_cost(2024) == 80
    assert quick_cost(2030) == 170

def test_price_trajectory():
    assert quick_cost(2026) > quick_cost(2024)

def test_oil_sands_cost():
    r = calculate_carbon_cost(production_bpd=100000, extraction_type="sagd", year=2030)
    assert r.annual_cost_cad > 0
    assert r.cost_per_bbl > 0

def test_refinery_cost():
    calc = CanadaCarbonCalculator()
    r = calc.calculate_refinery("imperial_strathcona", 2030)
    assert r.annual_cost_cad > 0

def test_compare_refineries():
    calc = CanadaCarbonCalculator()
    results = calc.compare_refineries(2030)
    assert "imperial_strathcona" in results

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
