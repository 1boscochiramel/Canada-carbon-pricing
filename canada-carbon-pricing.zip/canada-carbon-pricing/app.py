"""Canada Carbon Pricing - Streamlit App"""
import streamlit as st
import plotly.express as px
import sys
sys.path.insert(0, 'src')
from canada_carbon import calculate_carbon_cost, CanadaCarbonCalculator, quick_cost, PROVINCIAL_SYSTEMS, OIL_SANDS_INTENSITY

st.set_page_config(page_title="Canada Carbon Pricing", page_icon="🍁", layout="wide")
st.title("🍁 Canada Carbon Pricing Calculator")
st.markdown("Federal & Provincial Carbon Costs for Oil Sands, Refineries")

st.sidebar.header("⚙️ Configuration")
sector = st.sidebar.radio("Sector", ["Oil Sands", "Refinery"])
year = st.sidebar.slider("Year", 2024, 2035, 2026)

if sector == "Oil Sands":
    extraction = st.sidebar.selectbox("Extraction Type", ["sagd", "css", "mining"])
    production = st.sidebar.slider("Production (bpd)", 10000, 500000, 100000, 10000)
    result = calculate_carbon_cost(production_bpd=production, extraction_type=extraction, year=year)
else:
    calc = CanadaCarbonCalculator()
    result = calc.calculate_refinery("imperial_strathcona", year=year)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Annual Cost", f"${result.annual_cost_cad/1e6:.1f}M CAD")
c2.metric("Per Barrel", f"${result.cost_per_bbl:.2f}/bbl")
c3.metric("Carbon Price", f"${result.carbon_price:.0f}/t")
c4.metric("Emissions", f"{result.emissions_mtpa:.2f} Mt/yr")

tab1, tab2 = st.tabs(["📈 Price Trajectory", "🗺️ Provincial Comparison"])
with tab1:
    calc = CanadaCarbonCalculator()
    traj = calc.price_trajectory(list(range(2024, 2036)))
    fig = px.line(x=[t["year"] for t in traj], y=[t["federal_price"] for t in traj],
                  labels={"x": "Year", "y": "$/tonne CO2"})
    fig.update_layout(title="Federal Carbon Price Trajectory")
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    prices = calc.compare_provinces(year)
    fig2 = px.bar(x=list(prices.keys()), y=list(prices.values()), labels={"x": "Province", "y": "$/tonne"})
    st.plotly_chart(fig2, use_container_width=True)

st.markdown("---")
st.markdown("**Author:** Bosco Chiramel | ORCID: 0009-0001-8456-5302")
