# 🍁 Canada Carbon Pricing Calculator

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://img.shields.io/badge/tests-5%20passed-brightgreen.svg)]()

**Federal and provincial carbon pricing calculator for Canadian energy sector.**

## 🎯 Features

- **Federal Price Trajectory:** $80 (2024) → $170/tonne (2030)
- **Provincial Systems:** Alberta TIER, BC Carbon Tax, Quebec Cap-and-Trade, Saskatchewan OBPS
- **Oil Sands Modeling:** SAGD, CSS, Mining emission intensities
- **Refinery Coverage:** 8 major Canadian refineries
- **TIER Benchmarks:** Output-based allocation calculations

## 📊 Federal Carbon Price Trajectory

| Year | Price (CAD/tonne) |
|------|-------------------|
| 2024 | $80 |
| 2026 | $110 |
| 2028 | $140 |
| 2030 | $170 |

## 📊 Sample Oil Sands Cost (100k bpd SAGD, 2030)

- **Annual Cost:** $78.2M CAD
- **Per Barrel:** $2.38 CAD/bbl

## 🚀 Quick Start

```bash
git clone https://github.com/bosco-chiramel/canada-carbon-pricing.git
cd canada-carbon-pricing
pip install -r requirements.txt
streamlit run app.py
```

## 💻 Python Usage

```python
from canada_carbon import calculate_carbon_cost, quick_cost

# Federal price lookup
price = quick_cost(2030)  # $170/tonne

# Oil sands cost calculation
result = calculate_carbon_cost(
    production_bpd=100000,
    extraction_type="sagd",
    year=2030,
)
print(f"Annual Cost: ${result.annual_cost_cad/1e6:.1f}M")
print(f"Per Barrel: ${result.cost_per_bbl:.2f}/bbl")
```

## 🔬 Provincial Systems

| Province | System | Type |
|----------|--------|------|
| Alberta | TIER | Output-Based |
| BC | Carbon Tax | Direct Tax |
| Quebec | WCI Cap-and-Trade | Market |
| Saskatchewan | OBPS | Output-Based |
| Ontario | EPS | Output-Based |

## 📄 License

MIT License

## 👤 Author

**Bosco Chiramel** | [![ORCID](https://img.shields.io/badge/ORCID-0009--0001--8456--5302-green.svg)](https://orcid.org/0009-0001-8456-5302)
